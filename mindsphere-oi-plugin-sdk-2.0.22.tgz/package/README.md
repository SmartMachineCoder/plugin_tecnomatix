# Operations Insight Plugin SDK
This is the Software Development Kit for Operations Insight plugins.
It provides certain values such as the ID of the currently selected asset
and enables to emit certain parameters to the Operations Insight host application,
e.g. applying a date range.

- [Operations Insight Plugin SDK](#fleet-manager-plugin-sdk)
	- [Installation](#installation)
	- [Booting the plugin](#booting-the-plugin)
	- [Getting input parameters](#getting-input-parameters)
	- [Emit parameters to the host application](#emit-parameters-to-the-host-application)

## Installation
### From tarball
~~~bash
npm i mindsphere-oi-plugin-sdk-<version>.tgz
~~~

## Booting the plugin
In order to connect to the host application, you need to boot the plugin using the `oiPluginBootstrapper` once at the very start of your application:
~~~javascript
import {oiPluginBootstrapper} from "@mindsphere/oi-plugin-sdk";

oiPluginBootstrapper.boot();
~~~

The `boot` function optionally takes some startup options to initially apply:
~~~javascript
import {oiPluginBootstrapper, DateRange, TimeZone} from "@mindsphere/oi-plugin-sdk";

oiPluginBootstrapper.boot({
	// selects a specific asset
	assetId: 'f9f1ff3ccaa1401a98cf37d0c9144c7e',
	
	// navigate to another plugin
	pluginId: 'Aspects',
	
	// apply a date time range
	dateRange: new DateRange({
		start: new Date(2018,5,15),
		end: new Date(2018,6,15),
		timeZone: TimeZone.Local
	}),
	
	// enable the date time range picker in the plugin header
	enableDateTimeRangePicker: true,
	
	// provide an i18n map for the app's legal information
	appInfoI18n: {
		en: {
			displayName: 'My Fancy Operations Insight Plugin',
			appCopyright: 'Copyright (C) 2021, Acme Inc.',
			appVersion: '1.3.2',
			links: {
				default: [
					{
						'type': AppInfoLinkType.WWW,
						'name': 'Third-Party Software',
						'value': '/assets/ossReadme.html'
					},
					{
						'type': AppInfoLinkType.WWW,
						'name': 'Documentation',
						'value': '/assets/documentation.html'
					},
				],
			},
		},
		de: {/* ... */},
		// you may add any other language here that is supported by the Operations Insight
	},
});
~~~

The `boot` function returns a promise, so you can wait for the connection to become ready before doing other stuff.
Though you don't need to.
Instant listening for input and emitting of parameters are also supported.
The SDK will retain your output until the host connection becomes ready and will then emit the latest parameters.

## Getting input parameters
The input parameters are available as [RxJS](http://reactivex.io/rxjs/manual/overview.html) Observables.
In order to get the latest value and to get notified on updates, just subscribe to the respective proxy property:
~~~javascript
import {oiProxy} from "@mindsphere/oi-plugin-sdk";

// if true, the plugin tab is currently active
oiProxy.active.subscribe(active =>
	console.log(`component is ${active ? 'active' : 'inactive'}`
));

// the ID of the currently selected asset
oiProxy.assetId.subscribe(assetId => console.log(assetId));

// the currently chosen date time range
oiProxy.dateRange.subscribe(({start, end, timeZone} = {}) => {
	console.log(`from ${start} to ${end}`);
	console.log(`preferred time zone is ${timeZone}`);
});

// the current language selection ('en'|'de')
oiProxy.language.subscribe(language => console.log(language));
~~~

## Emit parameters to the host application
The proxy allows for emitting certain parameters to the host application:
~~~javascript
import {oiProxy, DateRange, TimeZone} from "@mindsphere/oi-plugin-sdk";

// select an asset
oiProxy.setAssetId('f9f1ff3ccaa1401a98cf37d0c9144c7e');

// apply a date time range
oiProxy.setDateRange(new DateRange({
	start: new Date(2018,5,15),
	end: new Date(2018,6,15),
	timeZone: TimeZone.Local,
}));

// navigate to another plugin, select an asset and/or apply a date time range
// (all properties are optional) 
oiProxy.navigate({
	pluginId: 'Aspects',
	assetId: 'f9f1ff3ccaa1401a98cf37d0c9144c7e',
	dateRange: new DateRange({
		start: new Date(2018,5,15),
		end: new Date(2018,6,15),
		timeZone: TimeZone.Local, // optional
	})
});

// en- or disable the date time range picker in the plugin header
oiProxy.enableDateTimeRangePicker();
oiProxy.disableDateTimeRangePicker();

// provide an i18n map for the app's legal information
oiProxy.setAppInfoI18n({
	appInfoI18n: {
		en: {
			displayName: 'My Fancy Operations Insight Plugin',
			appCopyright: 'Copyright (C) 2021, Acme Inc.',
			appVersion: '1.3.2',
			links: {
				default: [
					{
						'type': AppInfoLinkType.WWW,
						'name': 'Third-Party Software',
						'value': '/assets/ossReadme.html'
					},
					{
						'type': AppInfoLinkType.WWW,
						'name': 'Documentation',
						'value': '/assets/documentation.html'
					},
				],
			},
		},
		de: {/* ... */},
	},
})
~~~

If you have Observables for your plugin output, you may as well just subscribe the provided Observers:
~~~javascript
import {oiProxy} from "@mindsphere/oi-plugin-sdk";

myAssetIdObservable.subscribe(oiProxy.assetIdObserver);
myDateRangeObservable.subscribe(oiProxy.dateRangeObserver);
myNavigationObservable.subscribe(oiProxy.navigationObserver);
myDateTimeRangePickerOptionsObservable.subscribe(oiProxy.dateTimeRangePickerOptionsObserver);
myAppInfoI18nObservable.subscribe(oiProxy.appInfoI18nObserver);
~~~
